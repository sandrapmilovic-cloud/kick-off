# Workspace instructions

- App: Kickoff, Croatian-language football match demo PWA built with Vite, React, and TypeScript.
- Keep demo fixtures and score estimates visibly identified as sample data; do not imply live data or guaranteed outcomes.
- Keep saved picks local to the device unless a real backend is intentionally introduced.
- The same `dist` output is consumed by Capacitor for Android. Run `npm run build` after app changes.
- Keep the UI responsive, keyboard accessible, and consistent with the green, lime, and warm-neutral visual system.