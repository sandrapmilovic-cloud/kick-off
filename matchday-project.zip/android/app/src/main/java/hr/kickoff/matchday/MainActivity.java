package hr.kickoff.matchday;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
