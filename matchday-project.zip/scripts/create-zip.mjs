import { ZipArchive } from 'archiver'
import { createWriteStream } from 'node:fs'
import { readdir } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const projectRoot = fileURLToPath(new URL('../', import.meta.url))
const archivePath = path.join(projectRoot, 'matchday-project.zip')
const excluded = new Set(['.git', 'node_modules', 'dist', '.gradle', '.cache', 'build'])
const output = createWriteStream(archivePath)
const archive = new ZipArchive({ zlib: { level: 9 } })

archive.on('error', (error) => { throw error })
archive.pipe(output)

async function addFolder(folder, relativeFolder = '') {
  const entries = await readdir(folder, { withFileTypes: true })
  for (const entry of entries) {
    const relativePath = path.join(relativeFolder, entry.name)
    if (excluded.has(entry.name) || entry.name === 'matchday-project.zip' || entry.name === 'local.properties' || entry.name === '.env' || (entry.name.startsWith('.env.') && entry.name !== '.env.example')) continue
    const absolutePath = path.join(folder, entry.name)
    if (entry.isDirectory()) await addFolder(absolutePath, relativePath)
    else if (entry.isFile()) archive.file(absolutePath, { name: relativePath.replaceAll(path.sep, '/') })
  }
}

await addFolder(projectRoot)
await archive.finalize()
await new Promise((resolve, reject) => {
  output.once('close', resolve)
  output.once('error', reject)
})
console.log(`Created ${path.basename(archivePath)} (${archive.pointer()} bytes)`)