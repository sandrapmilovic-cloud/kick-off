import 'dotenv/config'
import express from 'express'
import { rateLimit } from 'express-rate-limit'
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const app = express()
const port = Number(process.env.API_PORT ?? 8787)
const apiKey = process.env.API_FOOTBALL_KEY?.trim() ?? ''
const apiBaseUrl = (process.env.API_FOOTBALL_BASE_URL ?? 'https://v3.football.api-sports.io').replace(/\/$/, '')
const dailyLimit = Math.max(1, Number(process.env.FOOTBALL_API_DAILY_LIMIT ?? 80))
const minuteLimit = Math.max(1, Number(process.env.FOOTBALL_API_PER_MINUTE_LIMIT ?? 6))
const timeoutMs = Math.max(1000, Number(process.env.FOOTBALL_API_TIMEOUT_MS ?? 12000))
const clientLimit = Math.max(1, Number(process.env.CLIENT_API_LIMIT_PER_MINUTE ?? 30))
const root = path.dirname(fileURLToPath(import.meta.url))
const quotaPath = path.resolve(root, '..', '.cache', 'api-quota.json')
const cache = new Map()
const minuteWindowMs = 60_000
let upstreamBlockedUntil = 0
let upstreamQueue = Promise.resolve()
let providerRemaining = null
let providerLimit = null

app.disable('x-powered-by')
app.set('trust proxy', process.env.TRUST_PROXY === 'true')
app.use((request, response, next) => {
  const origin = request.get('origin')
  const allowedOrigins = (process.env.FRONTEND_ORIGINS ?? '').split(',').map((value) => value.trim()).filter(Boolean)
  if (origin && (allowedOrigins.length === 0 || allowedOrigins.includes(origin))) {
    response.setHeader('Access-Control-Allow-Origin', origin)
    response.setHeader('Vary', 'Origin')
  }
  response.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS')
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  if (request.method === 'OPTIONS') return response.sendStatus(204)
  next()
})
app.use(express.json({ limit: '16kb' }))

const clientLimiter = rateLimit({
  windowMs: minuteWindowMs,
  limit: clientLimit,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'Previše zahtjeva s ovog uređaja. Pričekaj minutu prije pokušaja.' },
})

function utcDay() {
  return new Date().toISOString().slice(0, 10)
}

async function readQuota() {
  try {
    const stored = JSON.parse(await readFile(quotaPath, 'utf8'))
    if (stored.day === utcDay()) {
      return {
        day: stored.day,
        dailyUsed: Number(stored.dailyUsed) || 0,
        minuteRequests: Array.isArray(stored.minuteRequests) ? stored.minuteRequests.filter(Number.isFinite) : [],
      }
    }
  } catch {
    return { day: utcDay(), dailyUsed: 0, minuteRequests: [] }
  }
  return { day: utcDay(), dailyUsed: 0, minuteRequests: [] }
}

async function saveQuota(quota) {
  await mkdir(path.dirname(quotaPath), { recursive: true })
  const temporaryPath = `${quotaPath}.tmp`
  await writeFile(temporaryPath, JSON.stringify(quota), 'utf8')
  await rename(temporaryPath, quotaPath)
}

async function quotaStatus() {
  const quota = await readQuota()
  const activeRequests = quota.minuteRequests.filter((timestamp) => Date.now() - timestamp < minuteWindowMs)
  return {
    day: quota.day,
    dailyUsed: quota.dailyUsed,
    dailyLimit,
    minuteUsed: activeRequests.length,
    minuteLimit,
    providerRemaining,
    providerLimit,
    blockedUntil: upstreamBlockedUntil > Date.now() ? new Date(upstreamBlockedUntil).toISOString() : null,
  }
}

function apiError(status, message, retryAfterSeconds = null) {
  const error = new Error(message)
  error.status = status
  error.retryAfterSeconds = retryAfterSeconds
  return error
}

function validateDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null
  const parsed = new Date(`${value}T00:00:00.000Z`)
  if (Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0, 10) !== value) return null
  if (value < '2026-01-01') return null
  return value
}

async function providerRequest(endpoint, params, ttlMs) {
  if (!apiKey) throw apiError(503, 'API_FOOTBALL_KEY nije postavljen na proxy serveru.')
  const url = new URL(`${apiBaseUrl}/${endpoint}`)
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, String(value))
  const cacheKey = url.toString()
  const cached = cache.get(cacheKey)
  if (cached && cached.expiresAt > Date.now()) return { payload: cached.payload, cached: true }

  const requestTask = upstreamQueue.then(async () => {
    const secondLook = cache.get(cacheKey)
    if (secondLook && secondLook.expiresAt > Date.now()) return { payload: secondLook.payload, cached: true }
    if (upstreamBlockedUntil > Date.now()) {
      const retryAfter = Math.ceil((upstreamBlockedUntil - Date.now()) / 1000)
      throw apiError(429, 'API-Football je privremeno na hlađenju nakon ograničenja zahtjeva.', retryAfter)
    }

    const quota = await readQuota()
    const now = Date.now()
    quota.minuteRequests = quota.minuteRequests.filter((timestamp) => now - timestamp < minuteWindowMs)
    if (quota.dailyUsed >= dailyLimit) throw apiError(429, 'Dnevna zaštitna kvota aplikacije je dosegnuta.', 3600)
    if (quota.minuteRequests.length >= minuteLimit) {
      const retryAfter = Math.max(1, Math.ceil((quota.minuteRequests[0] + minuteWindowMs - now) / 1000))
      throw apiError(429, 'Zaštita od prečestih API poziva je aktivna.', retryAfter)
    }

    quota.dailyUsed += 1
    quota.minuteRequests.push(now)
    await saveQuota(quota)

    let upstreamResponse
    try {
      upstreamResponse = await fetch(url, {
        headers: { 'x-apisports-key': apiKey, accept: 'application/json' },
        signal: AbortSignal.timeout(timeoutMs),
      })
    } catch (error) {
      throw apiError(502, error.name === 'TimeoutError' ? 'API-Football nije odgovorio na vrijeme.' : 'API-Football trenutno nije dostupan.')
    }

    const remainingHeader = upstreamResponse.headers.get('x-ratelimit-requests-remaining')
    const limitHeader = upstreamResponse.headers.get('x-ratelimit-requests-limit')
    providerRemaining = remainingHeader !== null && Number.isFinite(Number(remainingHeader)) ? Number(remainingHeader) : null
    providerLimit = limitHeader !== null && Number.isFinite(Number(limitHeader)) ? Number(limitHeader) : null
    if (upstreamResponse.status === 429) {
      const parsedRetry = Number(upstreamResponse.headers.get('retry-after'))
      const retryAfter = Number.isFinite(parsedRetry) && parsedRetry > 0 ? parsedRetry : 60
      upstreamBlockedUntil = Date.now() + retryAfter * 1000
      throw apiError(429, 'API-Football je ograničio zahtjeve. Proxy je uveo pauzu.', retryAfter)
    }

    const payload = await upstreamResponse.json().catch(() => null)
    if (!upstreamResponse.ok) {
      const detail = payload?.errors ? JSON.stringify(payload.errors) : `HTTP ${upstreamResponse.status}`
      throw apiError(502, `API-Football je odbio zahtjev: ${detail}`)
    }
    if (payload?.errors && Object.keys(payload.errors).length > 0) {
      throw apiError(502, `API-Football greška: ${JSON.stringify(payload.errors)}`)
    }

    cache.set(cacheKey, { payload, expiresAt: Date.now() + ttlMs })
    return { payload, cached: false }
  })
  upstreamQueue = requestTask.catch(() => undefined)
  return requestTask
}

app.get('/api/health', async (_request, response, next) => {
  try {
    response.json({
      provider: 'API-Football',
      configured: Boolean(apiKey),
      timezone: 'Europe/Zagreb',
      minimumDate: '2026-01-01',
      protection: await quotaStatus(),
    })
  } catch (error) {
    next(error)
  }
})

app.get('/api/fixtures', clientLimiter, async (request, response, next) => {
  try {
    const date = validateDate(request.query.date)
    const page = Number(request.query.page ?? 1)
    if (!date) throw apiError(400, 'Odaberi ispravan datum od 1. siječnja 2026. nadalje.')
    if (!Number.isInteger(page) || page < 1) throw apiError(400, 'Broj stranice nije ispravan.')
    const result = await providerRequest('fixtures', {
      date,
      timezone: 'Europe/Zagreb',
      page,
    }, 5 * 60_000)
    response.json({ ...result.payload, cached: result.cached, timezone: 'Europe/Zagreb' })
  } catch (error) {
    next(error)
  }
})

app.get('/api/predictions', clientLimiter, async (request, response, next) => {
  try {
    const fixtureId = Number(request.query.fixture)
    if (!Number.isSafeInteger(fixtureId) || fixtureId < 1) throw apiError(400, 'ID utakmice nije ispravan.')
    const result = await providerRequest('predictions', { fixture: fixtureId }, 6 * 60 * 60_000)
    response.json({ ...result.payload, cached: result.cached })
  } catch (error) {
    next(error)
  }
})

app.use((error, _request, response, _next) => {
  if (error.retryAfterSeconds) response.setHeader('Retry-After', String(error.retryAfterSeconds))
  response.status(error.status ?? 500).json({ error: error.message ?? 'Neočekivana greška API proxyja.' })
})

app.listen(port, '0.0.0.0', () => {
  console.log(`Kickoff API proxy sluša na portu ${port}; API ključ ${apiKey ? 'je postavljen' : 'nije postavljen'}.`)
})