import { useEffect, useMemo, useState } from 'react'
import {
  Activity, ArrowDownRight, Bookmark, CalendarDays, Check, ChevronDown,
  ChevronRight, CircleAlert, CircleHelp, Clock3, Download, RefreshCw, Search,
  Settings2, ShieldCheck, Star, Target, Trophy, X,
} from 'lucide-react'
import {
  fetchApiStatus,
  fetchFixtures,
  fetchOdds,
  FIRST_SUPPORTED_DATE,
  FOOTBALL_TIMEZONE,
  loadApiKey,
  saveApiKey,
  type ApiStatus,
  type FootballFixture,
  type FootballOdds,
} from './footballApi'

type View = 'matches' | 'saved' | 'settings'
type SavedPick = { matchId: string; savedAt: number; fixture?: FootballFixture }
interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>
}
const savedKey = 'kickoff-saved-picks'
const initialDate = getZagrebDate()
const pageYear = new Date(`${initialDate}T12:00:00Z`).getUTCFullYear()

function getZagrebDate(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: FOOTBALL_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date)
  const part = (type: string) => parts.find((item) => item.type === type)?.value ?? '00'
  return `${part('year')}-${part('month')}-${part('day')}`
}

function shiftDate(date: string, amount: number) {
  const value = new Date(`${date}T12:00:00Z`)
  value.setUTCDate(value.getUTCDate() + amount)
  return value.toISOString().slice(0, 10)
}

function formatDate(date: string, options: Intl.DateTimeFormatOptions = {}) {
  return new Intl.DateTimeFormat('hr-HR', { timeZone: FOOTBALL_TIMEZONE, ...options })
    .format(new Date(`${date}T12:00:00Z`))
}

function formatFixtureDate(date: string, options: Intl.DateTimeFormatOptions = {}) {
  return new Intl.DateTimeFormat('hr-HR', { timeZone: FOOTBALL_TIMEZONE, ...options }).format(new Date(date))
}

function readSavedPicks(): SavedPick[] {
  try {
    const stored = localStorage.getItem(savedKey)
    return stored ? JSON.parse(stored) as SavedPick[] : []
  } catch {
    return []
  }
}

function localKickoff(isoDate: string) {
  return new Intl.DateTimeFormat('hr-HR', {
    timeZone: FOOTBALL_TIMEZONE,
    hour: '2-digit',
    minute: '2-digit',
  }).format(new Date(isoDate))
}

function fixtureStatusLabel(fixture: FootballFixture) {
  const labels: Record<string, string> = {
    NS: 'Nadolazi',
    TBD: 'Početak nije potvrđen',
    '1H': '1. poluvrijeme',
    HT: 'Poluvrijeme',
    '2H': '2. poluvrijeme',
    ET: 'Produžeci',
    BT: 'Stanka u produžecima',
    P: 'Penali',
    SUSP: 'Obustavljeno',
    INT: 'Prekinuto',
    FT: 'Završeno',
    AET: 'Završeno nakon produžetaka',
    PEN: 'Završeno nakon penala',
    PST: 'Odgođeno',
    CANC: 'Otkazano',
    ABD: 'Napušteno',
    AWD: 'Pobjeda dodijeljena',
    WO: 'Bez borbe',
    LIVE: 'Uživo',
  }
  return labels[fixture.fixture.status.short] ?? fixture.fixture.status.long
}

function displayErrors(error: unknown) {
  return error instanceof Error ? error.message : 'Zahtjev nije uspio.'
}

function KickoffApp() {
  const [view, setView] = useState<View>('matches')
  const [selectedDate, setSelectedDate] = useState(initialDate < FIRST_SUPPORTED_DATE ? FIRST_SUPPORTED_DATE : initialDate)
  const [league, setLeague] = useState('Sve lige')
  const [search, setSearch] = useState('')
  const [matches, setMatches] = useState<FootballFixture[]>([])
  const [savedPicks, setSavedPicks] = useState<SavedPick[]>(readSavedPicks)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [apiKey, setApiKey] = useState('')
  const [apiKeyLoaded, setApiKeyLoaded] = useState(false)
  const [apiStatus, setApiStatus] = useState<ApiStatus | null>(null)
  const [apiError, setApiError] = useState('')
  const [loadingFixtures, setLoadingFixtures] = useState(false)
  const [loadingMore, setLoadingMore] = useState(false)
  const [loadingPredictions, setLoadingPredictions] = useState(false)
  const [offlineFixtures, setOfflineFixtures] = useState(false)
  const [fixturePage, setFixturePage] = useState({ current: 1, total: 1 })
  const [prediction, setPrediction] = useState<FootballOdds | null>(null)
  const [predictionError, setPredictionError] = useState('')
  const [refreshToken, setRefreshToken] = useState(0)
  const [statusRefreshToken, setStatusRefreshToken] = useState(0)
  const [showFilters, setShowFilters] = useState(false)
  const [showMarketNote, setShowMarketNote] = useState(false)
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showInstallHelp, setShowInstallHelp] = useState(false)
  const [installError, setInstallError] = useState('')
  const [isInstalled, setIsInstalled] = useState(() => window.matchMedia('(display-mode: standalone)').matches)

  useEffect(() => {
    const handleInstallPrompt = (event: Event) => {
      event.preventDefault()
      setInstallPrompt(event as BeforeInstallPromptEvent)
    }
    const handleInstalled = () => {
      setIsInstalled(true)
      setInstallPrompt(null)
    }
    window.addEventListener('beforeinstallprompt', handleInstallPrompt)
    window.addEventListener('appinstalled', handleInstalled)
    return () => {
      window.removeEventListener('beforeinstallprompt', handleInstallPrompt)
      window.removeEventListener('appinstalled', handleInstalled)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem(savedKey, JSON.stringify(savedPicks))
  }, [savedPicks])

  useEffect(() => {
    let active = true
    loadApiKey()
      .then((key) => {
        if (!active) return
        setApiKey(key)
        setApiKeyLoaded(true)
        setLoadingFixtures(Boolean(key))
      })
      .catch((error: unknown) => {
        if (!active) return
        setApiError(`Nije moguće učitati spremljeni API ključ: ${displayErrors(error)}`)
        setApiKeyLoaded(true)
      })
    return () => { active = false }
  }, [])

  useEffect(() => {
    let active = true
    if (!apiKey) {
      return () => { active = false }
    }
    fetchApiStatus(apiKey)
      .then((status) => { if (active) setApiStatus(status) })
      .catch(() => { if (active) setApiStatus(null) })
    return () => { active = false }
  }, [apiKey, statusRefreshToken])

  useEffect(() => {
    let active = true
    if (!apiKeyLoaded) return () => { active = false }
    if (!apiKey) {
      return () => { active = false }
    }
    fetchFixtures(apiKey, selectedDate, 1)
      .then(({ payload, offlineFallback }) => {
        if (!active) return
        setMatches(payload.response)
        setFixturePage(payload.paging ?? { current: 1, total: 1 })
        setOfflineFixtures(offlineFallback)
        setSelectedId(payload.response[0]?.fixture.id ?? null)
        setPrediction(null)
        setPredictionError('')
        setLoadingPredictions(Boolean(payload.response[0]))
        if (!payload.response.length) setApiError('Za ovaj datum API-Football nije vratio utakmice.')
      })
      .catch((error: unknown) => { if (active) setApiError(displayErrors(error)) })
      .finally(() => { if (active) setLoadingFixtures(false) })
    return () => { active = false }
  }, [apiKey, apiKeyLoaded, refreshToken, selectedDate])

  const availableMatches = useMemo(() => {
    if (view !== 'saved') return matches
    const snapshots = savedPicks.flatMap((pick) => pick.fixture ? [pick.fixture] : [])
    return [...new Map([...snapshots, ...matches].map((match) => [match.fixture.id, match])).values()]
  }, [matches, savedPicks, view])
  const selectedMatch = availableMatches.find((match) => match.fixture.id === selectedId) ?? null
  const selectedMatchId = selectedMatch?.fixture.id ?? null
  const selectedIsSaved = selectedMatchId !== null && savedPicks.some((pick) => pick.matchId === String(selectedMatchId))

  useEffect(() => {
    let active = true
    if (selectedMatchId === null || !apiKey) return () => { active = false }
    fetchOdds(apiKey, selectedMatchId)
      .then(({ payload, offlineFallback }) => {
        if (!active) return
        setPrediction(payload)
        if (offlineFallback) setOfflineFixtures(true)
      })
      .catch((error: unknown) => { if (active) setPredictionError(displayErrors(error)) })
      .finally(() => { if (active) setLoadingPredictions(false) })
    return () => { active = false }
  }, [apiKey, selectedMatchId])

  const leagueNames = useMemo(() => ['Sve lige', ...new Set(availableMatches.map((match) => match.league.name).sort((a, b) => a.localeCompare(b, 'hr')))], [availableMatches])
  const filteredMatches = useMemo(() => {
    const query = search.trim().toLocaleLowerCase('hr')
    return availableMatches.filter((match) => {
      const isSaved = view !== 'saved' || savedPicks.some((pick) => pick.matchId === String(match.fixture.id))
      const matchesLeague = league === 'Sve lige' || match.league.name === league
      const matchesQuery = !query || `${match.teams.home.name} ${match.teams.away.name} ${match.league.name} ${match.league.country}`.toLocaleLowerCase('hr').includes(query)
      return isSaved && matchesLeague && matchesQuery
    })
  }, [availableMatches, league, savedPicks, search, view])

  const dateLabel = formatDate(selectedDate, { weekday: 'long', day: 'numeric', month: 'long' })

  function toggleSaved(match: FootballFixture) {
    const id = String(match.fixture.id)
    setSavedPicks((current) => current.some((pick) => pick.matchId === id)
      ? current.filter((pick) => pick.matchId !== id)
      : [...current, { matchId: id, savedAt: Date.now(), fixture: match }])
  }

  function resetFixtureView(hasApi = Boolean(apiKey)) {
    setMatches([])
    setSelectedId(null)
    setFixturePage({ current: 1, total: 1 })
    setOfflineFixtures(false)
    setApiError(hasApi ? '' : 'Unesi API-Football ključ u Postavkama za učitavanje utakmica.')
    setLoadingFixtures(hasApi)
    setPrediction(null)
    setPredictionError('')
    setLoadingPredictions(false)
  }

  function refreshFixtures() {
    resetFixtureView()
    setRefreshToken((value) => value + 1)
  }

  function selectMatch(matchId: number) {
    setSelectedId(matchId)
    setPrediction(null)
    setPredictionError('')
    setLoadingPredictions(Boolean(apiKey))
  }

  async function installApp() {
    setInstallError('')
    if (!installPrompt) {
      setShowInstallHelp(true)
      return
    }
    try {
      await installPrompt.prompt()
      const choice = await installPrompt.userChoice
      if (choice.outcome === 'accepted') setIsInstalled(true)
      setInstallPrompt(null)
    } catch (error) {
      setInstallError(`Instalacija nije uspjela: ${displayErrors(error)}`)
    }
  }

  async function loadNextPage() {
    if (!apiKey || loadingMore || fixturePage.current >= fixturePage.total) return
    setLoadingMore(true)
    setApiError('')
    try {
      const nextPage = fixturePage.current + 1
      const { payload, offlineFallback } = await fetchFixtures(apiKey, selectedDate, nextPage)
      setMatches((current) => [...current, ...payload.response])
      setFixturePage(payload.paging ?? { current: nextPage, total: nextPage })
      setOfflineFixtures(offlineFallback)
      if (payload.response.length === 0) setFixturePage({ current: nextPage, total: nextPage })
    } catch (error) {
      setApiError(displayErrors(error))
    } finally {
      setLoadingMore(false)
    }
  }

  function changeDate(date: string) {
    if (date >= FIRST_SUPPORTED_DATE && date !== selectedDate) {
      resetFixtureView()
      setSelectedDate(date)
    }
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#home" aria-label="Kickoff početna"><span className="brand-mark"><span /></span><span className="brand-word">kickoff<span>.</span></span></a>
        <div className="topbar-meta"><span className={apiStatus?.configured ? 'status-dot' : 'status-dot inactive'} /> API-Football <span className="meta-divider">/</span> {dateLabel}</div>
        <div className="topbar-actions">
          {!isInstalled && <button className="install-button" type="button" aria-label="Instaliraj Kickoff" onClick={installApp}><Download size={15} /><span>Instaliraj</span></button>}
          <button className="icon-button" type="button" title="O podacima i prognozama" aria-label="O podacima i prognozama" onClick={() => setShowMarketNote(true)}><CircleHelp size={18} /></button>
          <button className={view === 'settings' ? 'icon-button active' : 'icon-button'} type="button" title="Postavke" aria-label="Postavke" onClick={() => setView(view === 'settings' ? 'matches' : 'settings')}><Settings2 size={18} /></button>
          <button className="profile-button" type="button" aria-label="Kickoff"><span>GK</span></button>
        </div>
      </header>

      {view === 'settings' ? (
        <SettingsView key={apiKey} apiKey={apiKey} apiStatus={apiStatus} onSave={async (value) => {
          const status = await fetchApiStatus(value)
          await saveApiKey(value)
          setApiStatus(status)
          resetFixtureView(Boolean(value.trim()))
          setApiKey(value.trim())
        }} onRefresh={() => setStatusRefreshToken((value) => value + 1)} />
      ) : (
        <main id="home" className="workspace">
          <section className="main-column">
            <div className="page-heading">
              <div><div className="eyebrow"><span className="eyebrow-line" /> API-FOOTBALL <span className="demo-tag">PODACI API-JA</span></div><h1>Utakmice <span>i prognoze</span></h1><p className="heading-copy">Raspored i dostupne kvote Bet365, lokalno vrijeme Zagreb.</p></div>
              <div className="heading-mark" aria-hidden="true"><span>{String(fixturePage.current).padStart(2, '0')}</span><span>—</span><span>{String(fixturePage.total).padStart(2, '0')}</span></div>
            </div>

            <div className="overview-strip">
              <div className="overview-title"><Activity size={17} /><span>UTAKMICE DANA</span></div>
              <div className="overview-stat"><b>{String(matches.length).padStart(2, '0')}</b><span>učitano</span></div>
              <div className="overview-stat"><b>{new Set(matches.map((match) => match.league.name)).size.toString().padStart(2, '0')}</b><span>natjecanja</span></div>
              <div className="overview-note"><span className="mini-pulse" /> {dateLabel}</div>
            </div>

            <div className="toolbar">
              <div className="view-tabs" role="tablist" aria-label="Prikaz utakmica">
                <button className={view === 'matches' ? 'view-tab active' : 'view-tab'} type="button" role="tab" aria-selected={view === 'matches'} onClick={() => setView('matches')}><CalendarDays size={16} /> Utakmice <span>{matches.length}</span></button>
                <button className={view === 'saved' ? 'view-tab active' : 'view-tab'} type="button" role="tab" aria-selected={view === 'saved'} onClick={() => setView('saved')}><Bookmark size={15} /> Spremljeno <span>{savedPicks.length}</span></button>
              </div>
              <div className="toolbar-controls">
                <label className="search-field"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Pronađi klub" aria-label="Pronađi klub" /><kbd>/</kbd></label>
                <button className={showFilters ? 'filter-button selected' : 'filter-button'} type="button" onClick={() => setShowFilters((open) => !open)} aria-expanded={showFilters}><ChevronDown size={14} /><span>Lige</span></button>
                <button className="filter-button refresh-button" type="button" title="Osvježi utakmice" aria-label="Osvježi utakmice" onClick={refreshFixtures} disabled={loadingFixtures}><RefreshCw size={15} /></button>
              </div>
            </div>

            {showFilters && <div className="filter-panel" aria-label="Filtriraj lige"><span className="filter-label">NATJECANJE</span>{leagueNames.map((item) => <button key={item} type="button" className={league === item ? 'league-filter active' : 'league-filter'} onClick={() => setLeague(item)}>{item}</button>)}</div>}

            <div className="day-switch date-switch">
              <button type="button" className={selectedDate === initialDate ? 'day-tab active' : 'day-tab'} onClick={() => changeDate(initialDate)}>Danas</button>
              <button type="button" className={selectedDate === shiftDate(initialDate, 1) ? 'day-tab active' : 'day-tab'} onClick={() => changeDate(shiftDate(initialDate, 1))}>Sutra</button>
              <label className="date-picker"><CalendarDays size={14} /><input type="date" min={FIRST_SUPPORTED_DATE} value={selectedDate} onChange={(event) => changeDate(event.target.value)} aria-label="Odaberi datum od 2026. nadalje" /></label>
              <span className="day-date">{dateLabel}</span>
            </div>

            {offlineFixtures && <div className="offline-banner"><CircleAlert size={15} /> API nije dostupan: prikazani su zadnje spremljeni podaci za ovaj datum.</div>}
            {apiError && <div className="api-message" role="status"><CircleAlert size={16} /><span>{apiError}</span><button type="button" onClick={() => setView('settings')}>Postavke API-ja</button></div>}
            <div className="fixture-list">
              {loadingFixtures && view !== 'saved' ? <div className="loading-state"><RefreshCw size={19} className="spin" /><span>Učitavam utakmice iz API-Footballa…</span></div> : filteredMatches.length > 0 ? filteredMatches.map((match, index) => (
                <FixtureCard key={match.fixture.id} match={match} index={index} selected={selectedId === match.fixture.id} saved={savedPicks.some((pick) => pick.matchId === String(match.fixture.id))} savedView={view === 'saved'} onSelect={() => selectMatch(match.fixture.id)} onSave={() => toggleSaved(match)} />
              )) : <div className="empty-state"><span className="empty-icon"><Search size={20} /></span><h3>{view === 'saved' ? 'Nema spremljenih utakmica za ovaj datum' : apiStatus?.configured ? 'Nema utakmica za ovaj datum' : 'API-Football nije povezan'}</h3><p>{view === 'saved' ? 'Odaberi drugi datum ili spremi utakmicu zvjezdicom.' : apiStatus?.configured ? 'Provjeri drugi datum ili ukloni filtere.' : 'Unesi API-Football ključ u Postavkama.'}</p></div>}
            </div>
            {fixturePage.current < fixturePage.total && <button className="load-more" type="button" onClick={loadNextPage} disabled={loadingMore}>{loadingMore ? <RefreshCw size={15} className="spin" /> : <ChevronDown size={15} />}{loadingMore ? 'Učitavam sljedeću stranicu…' : `Učitaj još utakmica (${fixturePage.current}/${fixturePage.total})`}</button>}
            <div className="list-footer"><span>PRIKAZANO <b>{filteredMatches.length.toString().padStart(2, '0')}</b> <span className="footer-separator">/</span> UČITANO <b>{matches.length.toString().padStart(2, '0')}</b></span><span className="footer-demo"><span /> {offlineFixtures ? 'SPREMLJENI PODACI' : 'API-FOOTBALL'}</span></div>
          </section>

          <aside className="insight-column">
            <div className="insight-head"><div><span className="eyebrow"><span className="eyebrow-line" /> ANALIZA UTAKMICE</span><h2>Analiza <span>utakmice</span></h2></div>{selectedMatch && <button className="insight-save" type="button" onClick={() => toggleSaved(selectedMatch)} title={selectedIsSaved ? 'Ukloni spremljenu utakmicu' : 'Spremi utakmicu'} aria-label={selectedIsSaved ? 'Ukloni spremljenu utakmicu' : 'Spremi utakmicu'}><Star size={17} fill={selectedIsSaved ? 'currentColor' : 'none'} /></button>}</div>
            {selectedMatch ? <>
              <div className="insight-match">
                <div className="insight-league"><Trophy size={14} /><span>{selectedMatch.league.name}</span><span className="round-pill">{selectedMatch.league.country}</span></div>
                <div className="insight-teams">
                  <div className="insight-team"><TeamCrest name={selectedMatch.teams.home.name} logo={selectedMatch.teams.home.logo} large /><span>{selectedMatch.teams.home.name}</span><small>{selectedMatch.teams.home.id}</small></div>
                  <div className="insight-vs"><span>VS</span><b>{localKickoff(selectedMatch.fixture.date)}</b></div>
                  <div className="insight-team"><TeamCrest name={selectedMatch.teams.away.name} logo={selectedMatch.teams.away.logo} large /><span>{selectedMatch.teams.away.name}</span><small>{selectedMatch.teams.away.id}</small></div>
                </div>
                <div className="match-state"><span className="state-dot" /> {fixtureStatusLabel(selectedMatch).toLocaleUpperCase('hr')}</div>
              </div>
              <PredictionPanel prediction={prediction} loading={loadingPredictions} error={predictionError} onInfo={() => setShowMarketNote(true)} />
              <div className="form-panel fixture-detail-panel"><div className="form-heading"><span>UTAKMICA</span><span>{formatFixtureDate(selectedMatch.fixture.date, { day: 'numeric', month: 'short', year: 'numeric' })}</span></div><div className="detail-line"><Clock3 size={14} /><span>Početak</span><b>{localKickoff(selectedMatch.fixture.date)} · Zagreb</b></div><div className="detail-line"><Trophy size={14} /><span>Sezona</span><b>{selectedMatch.league.season} · {selectedMatch.league.round ?? 'Raspored'}</b></div>{selectedMatch.fixture.status.short !== 'NS' && <div className="detail-line"><Target size={14} /><span>Rezultat</span><b>{selectedMatch.goals.home ?? '-'} : {selectedMatch.goals.away ?? '-'}</b></div>}</div>
            </> : <div className="empty-insight"><Target size={22} /><p>Odaberi utakmicu za dostupne prognoze.</p></div>}
            <button className="details-link" type="button" onClick={() => setShowMarketNote(true)}>O kvotama i tipovima <ChevronRight size={15} /></button>
          </aside>
        </main>
      )}

      <footer className="site-footer"><span>© KICKOFF <span className="footer-year">{pageYear}</span></span><span>API PODACI <span className="footer-separator">/</span> EUROPE/ZAGREB</span><span className="footer-right">SEZONA 2026+ <ArrowDownRight size={13} /></span></footer>
      {installError && <div className="install-error" role="alert">{installError}<button type="button" onClick={() => setInstallError('')} aria-label="Zatvori obavijest"><X size={15} /></button></div>}
      {showInstallHelp && <InstallHelp onClose={() => setShowInstallHelp(false)} />}
      {showMarketNote && <MarketNote onClose={() => setShowMarketNote(false)} />}
    </div>
  )
}

function FixtureCard({ match, index, selected, saved, savedView, onSelect, onSave }: {
  match: FootballFixture
  index: number
  selected: boolean
  saved: boolean
  savedView: boolean
  onSelect: () => void
  onSave: () => void
}) {
  return (
    <article className={selected ? 'fixture-card selected' : 'fixture-card'}>
      <button className="fixture-main" type="button" onClick={onSelect} aria-label={`Otvori ${match.teams.home.name} protiv ${match.teams.away.name}`}>
        <div className="fixture-league"><span className="country-flag">{match.league.country.slice(0, 3).toUpperCase()}</span><span>{match.league.name}</span><span className="fixture-round">{savedView ? formatFixtureDate(match.fixture.date, { day: 'numeric', month: 'short' }) : match.league.round ?? `SEZONA ${match.league.season}`}</span></div>
        <div className="fixture-teams">
          <div className="team home-team"><TeamCrest name={match.teams.home.name} logo={match.teams.home.logo} /><span className="team-name">{match.teams.home.name}</span></div>
          <div className="fixture-time"><Clock3 size={13} /><span>{localKickoff(match.fixture.date)}</span><small>{match.fixture.status.short}</small></div>
          <div className="team away-team"><TeamCrest name={match.teams.away.name} logo={match.teams.away.logo} /><span className="team-name">{match.teams.away.name}</span></div>
        </div>
        <div className="fixture-bottom"><span className="fixture-status"><span /> {fixtureStatusLabel(match).toLocaleUpperCase('hr')}</span><span className="prediction-hint">Prognoze <b>{match.fixture.status.short === 'FT' ? `${match.goals.home ?? '-'} : ${match.goals.away ?? '-'}` : 'otvori analizu'}</b><ChevronRight size={14} /></span></div>
      </button>
      <button className={saved ? 'save-match saved' : 'save-match'} type="button" title={saved ? 'Ukloni spremljenu utakmicu' : 'Spremi utakmicu'} aria-label={saved ? 'Ukloni spremljenu utakmicu' : 'Spremi utakmicu'} onClick={onSave}><Star size={17} fill={saved ? 'currentColor' : 'none'} /></button>
      <span className="fixture-index">{String(index + 1).padStart(2, '0')}</span>
    </article>
  )
}

function TeamCrest({ name, logo, large = false }: { name: string; logo: string | null; large?: boolean }) {
  return logo
    ? <img className={large ? 'large-crest team-logo' : 'team-crest team-logo'} src={logo} alt="" loading="lazy" />
    : <span className={large ? 'large-crest crest-fallback' : 'team-crest crest-fallback'}>{name.slice(0, 1).toUpperCase()}</span>
}

function PredictionPanel({ prediction, loading, error, onInfo }: {
  prediction: FootballOdds | null
  loading: boolean
  error: string
  onInfo: () => void
}) {
  const formatProbability = (value: number | null) => value === null ? '—' : `${Math.round(value * 100)}%`
  const formatPick = (pick: FootballOdds['exactScore']) => pick
  ? `${pick.value} · ${pick.odds.toFixed(2).replace('.', ',')} (${formatProbability(pick.probability)})`
  : 'Nedostupno'
  const pairTip = (first: { value: string; probability: number | null } | null, second: { value: string; probability: number | null } | null) => {
  if (!first || !second || first.probability === null || second.probability === null) return 'Nedostupno'
  return first.probability >= second.probability ? first.value : second.value
  }
  const oneXtwoTip = prediction
  ? [
    { label: '1', probability: prediction.oneXtwo.home?.probability ?? null },
    { label: 'X', probability: prediction.oneXtwo.draw?.probability ?? null },
    { label: '2', probability: prediction.oneXtwo.away?.probability ?? null },
  ].filter((item) => item.probability !== null)
    .sort((first, second) => (second.probability ?? -1) - (first.probability ?? -1))[0]?.label ?? 'Nedostupno'
  : 'Nedostupno'
  const markets = [
  {
  name: '1X2',
  value: prediction ? `1: ${formatPick(prediction.oneXtwo.home)} · X: ${formatPick(prediction.oneXtwo.draw)} · 2: ${formatPick(prediction.oneXtwo.away)}` : 'Nedostupno',
  detail: `Tip s najvećom vjerojatnošću: ${oneXtwoTip}`,
  },
  { name: 'Više / manje 2,5', value: prediction ? `${pairTip(prediction.overUnder25.over, prediction.overUnder25.under)} · Više: ${formatPick(prediction.overUnder25.over)} · Manje: ${formatPick(prediction.overUnder25.under)}` : 'Nedostupno', detail: 'Kvote i vjerojatnosti iz Bet365 ponude' },
  { name: 'BTTS', value: prediction ? `${pairTip(prediction.btts.yes, prediction.btts.no)} · Da: ${formatPick(prediction.btts.yes)} · Ne: ${formatPick(prediction.btts.no)}` : 'Nedostupno', detail: 'Obje momčadi daju pogodak' },
  { name: 'Točan rezultat', value: formatPick(prediction?.exactScore ?? null), detail: 'Ishod s najvećom impliciranom vjerojatnošću' },
  { name: 'HT / FT', value: formatPick(prediction?.halfTimeFullTime ?? null), detail: 'Poluvrijeme / konačni ishod' },
  ]
  return (
  <section className="score-panel markets-panel">
    <div className="score-panel-top"><span><Target size={15} /> BET365 KVOTE I TIPOVI</span><button className="market-info-button" type="button" onClick={onInfo} aria-label="O vrstama predikcija"><CircleHelp size={14} /></button></div>
    {loading ? <div className="market-loading"><RefreshCw size={15} className="spin" /> Učitavam Bet365 kvote…</div> : error ? <p className="market-empty">{error}</p> : prediction ? <>
      {!prediction.bookmaker && <p className="market-empty">API nije vratio Bet365 kvote za ovu utakmicu. Ne prikazujemo zamjenske niti procijenjene kvote.</p>}
      {prediction.bookmaker && <div className="market-winner"><span>IZVOR</span><b>{prediction.bookmaker}{prediction.updatedAt ? ` · ažurirano ${formatFixtureDate(prediction.updatedAt, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}` : ''}</b></div>}
      <div className="markets-grid">{markets.map((market) => <div className="market-row" key={market.name}><span>{market.name}</span><b>{market.value}</b><small>{market.detail}</small></div>)}</div>
      <div className="score-disclaimer"><ShieldCheck size={14} /><span>Vjerojatnosti su normalizirane iz Bet365 decimalnih kvota, uključuju maržu tržišta i nisu jamstvo ishoda. Tržišta koja feed ne vrati ostaju nedostupna.</span></div>
    </> : <p className="market-empty">API-Football nije vratio podatke o kvotama.</p>}
  </section>
  )
}

function SettingsView({ apiKey, apiStatus, onSave, onRefresh }: {
  apiKey: string
  apiStatus: ApiStatus | null
  onSave: (value: string) => Promise<void>
  onRefresh: () => void
}) {
  const [draftKey, setDraftKey] = useState(apiKey)
  const [keyError, setKeyError] = useState('')
  const [saving, setSaving] = useState(false)
  const connected = apiStatus?.configured ?? false

  async function testAndSaveKey() {
  setSaving(true)
  setKeyError('')
  try {
    await onSave(draftKey)
  } catch (error) {
    setKeyError(displayErrors(error))
  } finally {
    setSaving(false)
  }
  }

  return (
    <main className="settings-workspace">
      <div className="page-heading settings-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> POSTAVKE APLIKACIJE</div><h1>Postavke <span>API-ja</span></h1><p className="heading-copy">Povezivanje izvora, vremenska zona i zaštita API kvote.</p></div><button className="filter-button" type="button" onClick={onRefresh}><RefreshCw size={15} /><span>Osvježi status</span></button></div>
      <div className="settings-grid">
        <section className="settings-section api-settings-section">
          <div className="settings-section-head"><span className="settings-icon"><Activity size={18} /></span><div><h2>API-Football</h2><p>Unesi ključ koji izdaje tvoj API-Football račun.</p></div></div>
          <div className={connected ? 'connection-state online' : 'connection-state offline'}><span />{connected ? 'Ključ je provjeren' : 'Ključ nije provjeren'}</div>
          <label className="settings-label" htmlFor="api-key">API-Football ključ</label>
          <div className="api-url-row"><input id="api-key" type="password" value={draftKey} onChange={(event) => setDraftKey(event.target.value)} placeholder="Unesi svoj API ključ" autoComplete="new-password" aria-invalid={Boolean(keyError)} aria-describedby={keyError ? 'api-key-error' : 'api-key-help'} /><button className="save-settings" type="button" onClick={testAndSaveKey} disabled={saving || !draftKey.trim()}>{saving ? <RefreshCw size={15} className="spin" /> : <Check size={15} />}{saving ? 'Provjera…' : 'Testiraj i spremi'}</button></div>
          {keyError && <p className="settings-error" id="api-key-error" role="alert">{keyError}</p>}
          <p className="settings-help" id="api-key-help">Ključ se sprema na ovom uređaju. API ključ unesen u web aplikaciju može se pregledati u pregledniku. APK na Androidu koristi šifriranu lokalnu pohranu, no vlasnik uređaja i dalje može izvući ključ.</p>
          <div className="secret-note"><ShieldCheck size={16} /><p>Android APK koristi nativni HTTPS klijent. Web preglednik ovisi o tome dopušta li API-Football zahtjeve s te domene (CORS). Za javnu distribuciju sigurniji je vlastiti HTTPS proxy.</p></div>
        </section>
        <section className="settings-section">
          <div className="settings-section-head"><span className="settings-icon"><ShieldCheck size={18} /></span><div><h2>API kvota</h2><p>Stanje kvote prema odgovoru API-Footballa.</p></div></div>
          <div className="protection-list"><div><span>Dnevni zahtjevi</span><b>{apiStatus?.requestCount ?? '—'} / {apiStatus?.requestLimit ?? '—'}</b></div><div><span>Aktivni plan</span><b>{apiStatus?.plan ?? '—'}</b></div><div><span>Vrijedi do</span><b>{apiStatus?.expiresAt ?? '—'}</b></div><div><span>Izvor kvota</span><b>Bet365, samo ako ga feed vrati</b></div></div>
          <p className="settings-help">Dostupnost i opseg utakmica, predikcija i Bet365 tržišta ovise o API-Football planu, ligi i utakmici.</p>
        </section>
        <section className="settings-section settings-static">
          <div className="settings-section-head"><span className="settings-icon"><CalendarDays size={18} /></span><div><h2>Natjecanja i vrijeme</h2><p>Globalni raspored filtrira se po odabranom datumu.</p></div></div>
          <div className="protection-list"><div><span>Izvor</span><b>API-Football v3</b></div><div><span>Najraniji datum</span><b>1. 1. 2026.</b></div><div><span>Obuhvat datuma</span><b>2026. nadalje</b></div><div><span>Vremenska zona</span><b>Europe/Zagreb</b></div><div><span>Učitavanje svih utakmica</span><b>Straničenje API-ja</b></div></div>
        </section>
        <section className="settings-section settings-static">
          <div className="settings-section-head"><span className="settings-icon"><Target size={18} /></span><div><h2>Tipovi predikcija</h2><p>Prikazuje se samo ono što vraća API.</p></div></div>
          <div className="market-availability"><span className="market-available">Tražene Bet365 kvote</span><p>1X2, više/manje 2,5, BTTS, točan rezultat i HT/FT prikazuju se kad ih API-Football vrati za odabranu utakmicu.</p><span className="market-unavailable">Bez zamjenskih tipova</span><p>Ako Bet365 ili određeno tržište nisu dostupni u tvom API planu, polje ostaje označeno kao nedostupno. Vjerojatnosti su izračunate iz decimalnih kvota s uklonjenom maržom.</p></div>
        </section>
      </div>
    </main>
  )
}

function InstallHelp({ onClose }: { onClose: () => void }) {
  return <div className="modal-backdrop" role="presentation" onClick={onClose}><section className="note-modal install-modal" role="dialog" aria-modal="true" aria-labelledby="install-help-title" onClick={(event) => event.stopPropagation()}><button className="modal-close" type="button" onClick={onClose} aria-label="Zatvori"><X size={19} /></button><span className="modal-icon"><Download size={19} /></span><span className="eyebrow"><span className="eyebrow-line" /> KICKOFF · INSTALACIJA</span><h2 id="install-help-title">Dodaj Kickoff na uređaj</h2><p><b>Računalo:</b> u Chromeu ili Edgeu odaberi ikonu instalacije u adresnoj traci ili izbornik preglednika → „Instaliraj Kickoff”.</p><p><b>Android:</b> u Chromeu otvori izbornik ⋮ → „Instaliraj aplikaciju” ili „Dodaj na početni zaslon”.</p><p><b>iPhone/iPad:</b> otvori ovu stranicu u Safariju, dodirni Dijeli → „Dodaj na početni zaslon”.</p><p className="install-requirement">Instalacija iz preglednika zahtijeva sigurnu HTTPS adresu. Na računalu za lokalni razvoj radi i localhost.</p><button type="button" className="modal-done" onClick={onClose}>Razumijem <ChevronRight size={15} /></button></section></div>
}

function MarketNote({ onClose }: { onClose: () => void }) {
  return <div className="modal-backdrop" role="presentation" onClick={onClose}><section className="note-modal" role="dialog" aria-modal="true" aria-labelledby="market-note-title" onClick={(event) => event.stopPropagation()}><button className="modal-close" type="button" onClick={onClose} aria-label="Zatvori"><X size={19} /></button><span className="modal-icon"><Target size={19} /></span><span className="eyebrow"><span className="eyebrow-line" /> API-FOOTBALL V3 · BET365</span><h2 id="market-note-title">O kvotama i tipovima</h2><p>Za odabranu utakmicu aplikacija traži Bet365 kvote za 1X2, više/manje 2,5, BTTS, točan rezultat i HT/FT. Vjerojatnosti za 1X2, 2,5 i BTTS računaju se iz decimalnih kvota uz normalizaciju tržišne marže.</p><p>Točan rezultat i HT/FT prikazuju opciju s najvećom impliciranom vjerojatnošću među vraćenim kvotama. Dostupnost ovisi o API-Football planu i feedu; nedostupna tržišta ne nadomještaju se. Kvote i procjene ne jamče ishod.</p><button type="button" className="modal-done" onClick={onClose}>Razumijem <ChevronRight size={15} /></button></section></div>
}

export default KickoffApp