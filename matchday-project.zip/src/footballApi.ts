import { Capacitor, CapacitorHttp } from '@capacitor/core'
import { SecureStorage } from '@aparajita/capacitor-secure-storage'

export const FOOTBALL_TIMEZONE = 'Europe/Zagreb'
export const FIRST_SUPPORTED_DATE = '2026-01-01'
const API_BASE_URL = 'https://v3.football.api-sports.io'
const API_KEY_STORAGE_KEY = 'kickoff-football-api-key'

export interface FootballFixture {
  fixture: {
    id: number
    date: string
    timestamp: number
    status: { long: string; short: string; elapsed: number | null }
  }
  league: {
    id: number
    name: string
    country: string
    logo: string | null
    flag: string | null
    season: number
    round: string | null
  }
  teams: {
    home: { id: number; name: string; logo: string | null; winner: boolean | null }
    away: { id: number; name: string; logo: string | null; winner: boolean | null }
  }
  goals: { home: number | null; away: number | null }
}

export interface ApiPage<T> {
  errors: Record<string, unknown> | unknown[]
  results: number
  paging: { current: number; total: number }
  response: T[]
}

export interface ApiStatus {
  provider: string
  configured: boolean
  requestCount: number | null
  requestLimit: number | null
  plan: string | null
  expiresAt: string | null
}

export interface MarketPick {
  value: string
  odds: number
  probability: number | null
}

export interface FootballOdds {
  bookmaker: string | null
  updatedAt: string | null
  oneXtwo: { home: MarketPick | null; draw: MarketPick | null; away: MarketPick | null }
  overUnder25: { over: MarketPick | null; under: MarketPick | null }
  btts: { yes: MarketPick | null; no: MarketPick | null }
  exactScore: MarketPick | null
  halfTimeFullTime: MarketPick | null
}

export class ApiRequestError extends Error {
  status: number
  retryAfter: number | null

  constructor(message: string, status: number, retryAfter: number | null = null) {
    super(message)
    this.name = 'ApiRequestError'
    this.status = status
    this.retryAfter = retryAfter
  }
}

interface CachedResponse<T> {
  payload: T
  offlineFallback: boolean
}

interface ApiOddsResponse {
  update?: string
  bookmakers?: Array<{
    name: string
    bets?: Array<{
      name: string
      values?: Array<{ value: string; odd: string }>
    }>
  }>
}

export async function loadApiKey() {
  if (Capacitor.isNativePlatform()) return await SecureStorage.getItem(API_KEY_STORAGE_KEY) ?? ''
  return localStorage.getItem(API_KEY_STORAGE_KEY) ?? ''
}

export async function saveApiKey(value: string) {
  const key = value.trim()
  if (!key) throw new Error('Unesi API-Football ključ.')
  if (Capacitor.isNativePlatform()) await SecureStorage.setItem(API_KEY_STORAGE_KEY, key)
  else localStorage.setItem(API_KEY_STORAGE_KEY, key)
}

async function requestJson<T>(apiKey: string, endpoint: string, params: Record<string, string> = {}): Promise<T> {
  if (!apiKey.trim()) throw new ApiRequestError('U Postavkama unesi API-Football ključ.', 0)
  const url = new URL(`${API_BASE_URL}/${endpoint}`)
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value)

  let status: number
  let data: unknown
  let retryAfterHeader: string | null
  try {
    const headers = { 'x-apisports-key': apiKey.trim(), accept: 'application/json' }
    if (Capacitor.isNativePlatform()) {
      const response = await CapacitorHttp.get({ url: url.toString(), headers, responseType: 'json' })
      status = response.status
      data = response.data
      retryAfterHeader = response.headers['Retry-After'] ?? response.headers['retry-after'] ?? null
    } else {
      const response = await fetch(url, { headers, cache: 'no-store' })
      status = response.status
      retryAfterHeader = response.headers.get('Retry-After')
      try {
        data = await response.json()
      } catch {
        throw new ApiRequestError('API-Football je vratio odgovor koji nije valjani JSON.', response.status)
      }
    }
  } catch (error) {
    if (error instanceof ApiRequestError) throw error
    throw new ApiRequestError('Nije moguće spojiti se na API-Football. Provjeri internet i podršku za izravne API zahtjeve.', 0)
  }

  if (typeof data !== 'object' || data === null) {
    throw new ApiRequestError('API-Football je vratio neočekivani odgovor.', status)
  }
  const payload = data as { errors?: Record<string, unknown> | unknown[]; message?: string } & T
  if (status < 200 || status >= 300) {
    const errorDetails = payload.errors ? JSON.stringify(payload.errors) : ''
    const message = status === 401 || status === 403
      ? 'API-Football je odbio ključ. Provjeri je li valjan i ima li aktivan plan.'
      : errorDetails || payload.message || `API-Football zahtjev nije uspio (HTTP ${status}).`
    const retryAfter = Number(retryAfterHeader)
    throw new ApiRequestError(message, status, Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter : null)
  }
  if (payload.errors && Object.keys(payload.errors).length > 0) {
    throw new ApiRequestError(`API-Football greška: ${JSON.stringify(payload.errors)}`, status)
  }
  return payload
}

async function requestCached<T>(apiKey: string, endpoint: string, params: Record<string, string>, cacheKey: string, ttlMs: number): Promise<CachedResponse<T>> {
  const storageKey = `kickoff-api-cache:${cacheKey}`
  let cached: { expiresAt: number; payload: T } | null = null
  try {
    const stored = localStorage.getItem(storageKey)
    cached = stored ? JSON.parse(stored) as { expiresAt: number; payload: T } : null
  } catch {
    cached = null
  }

  if (cached && cached.expiresAt > Date.now()) return { payload: cached.payload, offlineFallback: false }

  try {
    const payload = await requestJson<T>(apiKey, endpoint, params)
    try {
      localStorage.setItem(storageKey, JSON.stringify({ expiresAt: Date.now() + ttlMs, payload }))
    } catch {
      return { payload, offlineFallback: false }
    }
    return { payload, offlineFallback: false }
  } catch (error) {
    if (cached && (!(error instanceof ApiRequestError) || error.status === 0 || error.status >= 500)) {
      return { payload: cached.payload, offlineFallback: true }
    }
    throw error
  }
}

export async function fetchApiStatus(apiKey: string): Promise<ApiStatus> {
  const payload = await requestJson<ApiPage<{
    requests?: { current?: number; limit_day?: number }
    subscription?: { plan?: string; end?: string }
  }>>(apiKey, 'status')
  const account = payload.response?.[0]
  if (!account) throw new ApiRequestError('API-Football nije vratio status računa.', 502)
  return {
    provider: 'API-Football',
    configured: true,
    requestCount: Number.isFinite(account.requests?.current) ? account.requests?.current ?? null : null,
    requestLimit: Number.isFinite(account.requests?.limit_day) ? account.requests?.limit_day ?? null : null,
    plan: account.subscription?.plan ?? null,
    expiresAt: account.subscription?.end ?? null,
  }
}

export function fetchFixtures(apiKey: string, date: string, page: number) {
  return requestCached<ApiPage<FootballFixture>>(
    apiKey,
    'fixtures',
    { date, timezone: FOOTBALL_TIMEZONE, page: String(page) },
    `fixtures:${date}:${page}`,
    5 * 60_000,
  )
}

function normalize(value: string) {
  return value.toLocaleLowerCase('en').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ' ').trim()
}

function decimalOdds(value: string) {
  const parsed = Number.parseFloat(value.replace(',', '.'))
  return Number.isFinite(parsed) && parsed > 1 ? parsed : null
}

function pickPair(values: Array<{ value: string; odd: string }>, isFirst: (value: string) => boolean, isSecond: (value: string) => boolean) {
  const matching = values.flatMap((item) => {
    const odds = decimalOdds(item.odd)
    return odds === null ? [] : [{ value: item.value, odds, probability: 1 / odds }]
  })
  const firstIndex = matching.findIndex((item) => isFirst(normalize(item.value)))
  const secondIndex = matching.findIndex((item) => isSecond(normalize(item.value)))
  const total = (firstIndex >= 0 ? matching[firstIndex].probability : 0) + (secondIndex >= 0 ? matching[secondIndex].probability : 0)
  const makePick = (index: number): MarketPick | null => index < 0 ? null : {
    value: matching[index].value,
    odds: matching[index].odds,
    probability: total > 0 ? matching[index].probability / total : null,
  }
  return [makePick(firstIndex), makePick(secondIndex)] as const
}

function pickOutcomes(values: Array<{ value: string; odd: string }>, matchers: Array<(value: string) => boolean>) {
  const matching = matchers.map((matcher) => {
    const item = values.find((candidate) => matcher(normalize(candidate.value)))
    const odds = item ? decimalOdds(item.odd) : null
    return item && odds !== null ? { value: item.value, odds, probability: 1 / odds } : null
  })
  const total = matching.reduce((sum, item) => sum + (item?.probability ?? 0), 0)
  return matching.map((item) => item && ({
    value: item.value,
    odds: item.odds,
    probability: total > 0 ? item.probability / total : null,
  }))
}

function mostLikely(values: Array<{ value: string; odd: string }>): MarketPick | null {
  const valid = values.flatMap((item) => {
    const odds = decimalOdds(item.odd)
    return odds === null ? [] : [{ value: item.value, odds }]
  })
  const selected = valid.reduce<(typeof valid)[number] | null>((best, item) => !best || item.odds < best.odds ? item : best, null)
  if (!selected) return null
  const total = valid.reduce((sum, item) => sum + 1 / item.odds, 0)
  return { value: selected.value, odds: selected.odds, probability: total > 0 ? (1 / selected.odds) / total : null }
}

function findMarket(bets: NonNullable<ApiOddsResponse['bookmakers']>[number]['bets'], match: (name: string) => boolean) {
  return bets?.find((bet) => match(normalize(bet.name)))?.values ?? []
}

function isHome(value: string) {
  return value === '1' || value.startsWith('home')
}

function isDraw(value: string) {
  return value === 'x' || value === 'draw'
}

function isAway(value: string) {
  return value === '2' || value.startsWith('away')
}

export function parseBet365Odds(response: ApiOddsResponse[]): FootballOdds {
  const fixtureOdds = response?.[0]
  const bookmaker = fixtureOdds?.bookmakers?.find((item) => normalize(item.name) === 'bet365')
  const bets = bookmaker?.bets ?? []
  const matchWinner = findMarket(bets, (name) => name === 'match winner' || name === 'match result' || name === 'fulltime result')
  const [home, draw, away] = pickOutcomes(matchWinner, [isHome, isDraw, isAway])
  const totalOdds = findMarket(bets, (name) => name.includes('over under') || name.includes('total goals'))
    .filter((item) => /\b2[.,]5\b/.test(item.value))
  const overUnder = pickPair(totalOdds, (value) => value.startsWith('over'), (value) => value.startsWith('under'))
  const bttsOdds = findMarket(bets, (name) => name.includes('both teams score') || name.includes('both teams to score') || name === 'btts')
  const btts = pickPair(bttsOdds, (value) => value === 'yes', (value) => value === 'no')
  const exactScoreOdds = findMarket(bets, (name) => name.includes('exact score') || name.includes('correct score'))
  const halfTimeFullTimeOdds = findMarket(bets, (name) => name === 'ht ft' || name.includes('half time full time') || name.includes('half time result full time result'))

  return {
    bookmaker: bookmaker?.name ?? null,
    updatedAt: fixtureOdds?.update ?? null,
    oneXtwo: { home: home ?? null, draw: draw ?? null, away: away ?? null },
    overUnder25: { over: overUnder[0], under: overUnder[1] },
    btts: { yes: btts[0], no: btts[1] },
    exactScore: mostLikely(exactScoreOdds),
    halfTimeFullTime: mostLikely(halfTimeFullTimeOdds),
  }
}

export function fetchOdds(apiKey: string, fixtureId: number) {
  return requestCached<ApiPage<ApiOddsResponse>>(
    apiKey,
    'odds',
    { fixture: String(fixtureId) },
    `odds:${fixtureId}`,
    5 * 60_000,
  ).then(({ payload, offlineFallback }) => ({
    payload: parseBet365Odds(payload.response ?? []),
    offlineFallback,
  }))
}
